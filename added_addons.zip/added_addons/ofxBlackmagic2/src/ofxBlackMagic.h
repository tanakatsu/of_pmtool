#include "ofxBlackmagic/Iterator.h"
#include "ofxBlackmagic/Input.h"

#undef small