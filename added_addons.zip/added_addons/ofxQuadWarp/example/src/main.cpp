#include "ofMain.h"
#include "ofApp.h"

int main( ){
	ofSetupOpenGL(900, 768, OF_WINDOW);
	ofRunApp( new ofApp());
}
